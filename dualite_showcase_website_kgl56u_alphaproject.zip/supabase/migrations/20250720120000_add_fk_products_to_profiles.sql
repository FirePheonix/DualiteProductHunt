/*
# [Add Foreign Key from Products to Profiles]
This migration adds a direct foreign key relationship from the `products` table to the `profiles` table. This is necessary for the application to correctly fetch the author's name for each product in a single query.

## Query Description:
- This operation adds a new foreign key constraint named `products_author_id_fkey`.
- It links the `author_id` column in the `products` table to the `id` column in the `profiles` table.
- This change is non-destructive and should not affect existing data. It formalizes a relationship that was already implicit.
- It also adds `ON DELETE CASCADE` to ensure that if a user's profile is deleted, all their associated products are also removed, maintaining data integrity.

## Metadata:
- Schema-Category: ["Structural"]
- Impact-Level: ["Low"]
- Requires-Backup: [false]
- Reversible: [true] (The constraint can be dropped)

## Structure Details:
- Table Affected: `public.products`
- Constraint Added: `products_author_id_fkey` on column `author_id`

## Security Implications:
- RLS Status: [Unaffected]
- Policy Changes: [No]
- Auth Requirements: [None]

## Performance Impact:
- Indexes: [An index on the foreign key column is usually created automatically, which can improve join performance.]
- Estimated Impact: [Low, positive impact on query performance.]
*/
ALTER TABLE public.products
ADD CONSTRAINT products_author_id_fkey
FOREIGN KEY (author_id) REFERENCES public.profiles(id)
ON DELETE CASCADE;
