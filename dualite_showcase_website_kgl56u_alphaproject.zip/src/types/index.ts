export interface Profile {
  id: string;
  full_name: string;
}

export interface Product {
  id: number;
  name: string;
  description: string;
  image_url: string;
  tags: string[];
  created_at: string;
  user_id: string;
  profiles: Profile | null;
  upvotes_count: number;
  user_has_upvoted: boolean;
}
