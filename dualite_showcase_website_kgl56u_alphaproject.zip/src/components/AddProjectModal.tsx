import { useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { supabase } from '../lib/supabaseClient';
import { X, Loader2, UploadCloud, FileImage } from 'lucide-react';

const AddProjectModal = () => {
  const { user, closeAddProjectModal } = useAuth();
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [tags, setTags] = useState('');
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setImageFile(file);
      const reader = new FileReader();
      reader.onloadend = () => {
        setImagePreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !imageFile) {
      setError('Please fill all fields and select an image.');
      return;
    }

    setLoading(true);
    setError(null);

    try {
      // 1. Upload image to Supabase Storage
      const fileExt = imageFile.name.split('.').pop();
      const fileName = `${user.id}-${Date.now()}.${fileExt}`;
      const filePath = `product-images/${fileName}`;

      const { error: uploadError } = await supabase.storage
        .from('product-images')
        .upload(filePath, imageFile);

      if (uploadError) throw uploadError;

      // 2. Get public URL of the uploaded image
      const { data: { publicUrl } } = supabase.storage
        .from('product-images')
        .getPublicUrl(filePath);

      if (!publicUrl) throw new Error("Could not get public URL for the image.");

      // 3. Insert project data into the 'products' table
      const tagsArray = tags.split(',').map(tag => tag.trim()).filter(Boolean);

      const { error: insertError } = await supabase.from('products').insert({
        name,
        description,
        tags: tagsArray,
        image_url: publicUrl,
        user_id: user.id,
      });

      if (insertError) throw insertError;
      
      // Success
      setLoading(false);
      closeAddProjectModal();
      // Optionally, you could trigger a refetch of products here
      window.location.reload(); // Simple way to refresh data

    } catch (err: any) {
      setError(err.message || 'An unexpected error occurred.');
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/70 z-50 flex items-center justify-center backdrop-blur-sm">
      <div className="bg-brand-gray-darker border border-brand-gray-dark rounded-xl p-8 w-full max-w-2xl m-4 relative max-h-[90vh] overflow-y-auto">
        <button
          onClick={closeAddProjectModal}
          className="absolute top-4 right-4 text-brand-gray hover:text-white transition-colors"
        >
          <X className="w-6 h-6" />
        </button>

        <div className="text-center mb-6">
          <h2 className="text-2xl font-bold mb-2">Add a New Project</h2>
          <p className="text-brand-gray">Showcase your creation to the community.</p>
        </div>

        {error && <p className="bg-red-500/20 text-red-400 text-sm p-3 rounded-md mb-4 text-center">{error}</p>}

        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label htmlFor="name" className="block text-sm font-medium text-brand-gray-light mb-2">Project Name</label>
            <input id="name" type="text" placeholder="e.g., MindMap Pro" value={name} onChange={(e) => setName(e.target.value)} required className="w-full bg-brand-gray-dark border border-brand-gray-medium rounded-lg px-4 py-3 text-white placeholder-brand-gray focus:outline-none focus:border-brand-green transition-colors" />
          </div>

          <div>
            <label htmlFor="description" className="block text-sm font-medium text-brand-gray-light mb-2">Description</label>
            <textarea id="description" placeholder="A short, catchy description of your project." value={description} onChange={(e) => setDescription(e.target.value)} required rows={4} className="w-full bg-brand-gray-dark border border-brand-gray-medium rounded-lg px-4 py-3 text-white placeholder-brand-gray focus:outline-none focus:border-brand-green transition-colors" />
          </div>

          <div>
            <label htmlFor="tags" className="block text-sm font-medium text-brand-gray-light mb-2">Tags (comma-separated)</label>
            <input id="tags" type="text" placeholder="e.g., Productivity, AI, SaaS" value={tags} onChange={(e) => setTags(e.target.value)} required className="w-full bg-brand-gray-dark border border-brand-gray-medium rounded-lg px-4 py-3 text-white placeholder-brand-gray focus:outline-none focus:border-brand-green transition-colors" />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-brand-gray-light mb-2">Project Thumbnail</label>
            <div className="mt-2 flex justify-center rounded-lg border border-dashed border-brand-gray-medium px-6 py-10">
              <div className="text-center">
                {imagePreview ? (
                  <img src={imagePreview} alt="Preview" className="mx-auto h-32 w-auto rounded-md object-contain" />
                ) : (
                  <UploadCloud className="mx-auto h-12 w-12 text-brand-gray" aria-hidden="true" />
                )}
                <div className="mt-4 flex text-sm leading-6 text-brand-gray-light">
                  <label htmlFor="file-upload" className="relative cursor-pointer rounded-md font-semibold text-brand-green focus-within:outline-none focus-within:ring-2 focus-within:ring-brand-green focus-within:ring-offset-2 focus-within:ring-offset-brand-gray-darker hover:text-brand-green/90">
                    <span>Upload a file</span>
                    <input id="file-upload" name="file-upload" type="file" className="sr-only" accept="image/png, image/jpeg, image/gif" onChange={handleImageChange} required />
                  </label>
                  <p className="pl-1">or drag and drop</p>
                </div>
                <p className="text-xs leading-5 text-brand-gray">PNG, JPG, GIF up to 10MB</p>
                {imageFile && <p className="text-xs text-brand-green mt-2 flex items-center justify-center gap-2"><FileImage className="w-4 h-4" /> {imageFile.name}</p>}
              </div>
            </div>
          </div>

          <button type="submit" disabled={loading} className="w-full mt-6 bg-brand-green text-black font-bold py-3 rounded-lg hover:bg-brand-green/90 transition-colors flex items-center justify-center disabled:opacity-50">
            {loading && <Loader2 className="w-5 h-5 mr-2 animate-spin" />}
            {loading ? 'Submitting...' : 'Submit Project'}
          </button>
        </form>
      </div>
    </div>
  );
};

export default AddProjectModal;
