import { Users, Heart, MessageCircle, Zap } from 'lucide-react';

const CommunitySection = () => {
  const communityStats = [
    {
      icon: Users,
      value: "12.5K",
      label: "Active Members",
      color: "text-brand-blue",
      bgColor: "bg-brand-blue/10",
    },
    {
      icon: Heart,
      value: "89.2K",
      label: "Products Loved",
      color: "text-red-400",
      bgColor: "bg-red-400/10",
    },
    {
      icon: MessageCircle,
      value: "45.7K",
      label: "Comments",
      color: "text-brand-green",
      bgColor: "bg-brand-green/10",
    },
    {
      icon: Zap,
      value: "2.3K",
      label: "Daily Upvoters",
      color: "text-brand-yellow",
      bgColor: "bg-brand-yellow/10",
    },
  ];

  const whyJoinPoints = [
    "Get valuable feedback from real users",
    "Connect with potential collaborators",
    "Gain exposure for your products",
    "Learn from successful creators",
  ];

  const recentCreators = [
    { name: "Shariff Shaz", initials: "SS", isOnline: true, hasAvatar: false },
    { name: "Shariff Shaz", initials: "SS", isOnline: true, hasAvatar: false },
    { name: "Shariff Shaz", initials: "SS", isOnline: true, hasAvatar: false },
    { name: "Shariff Shaz", initials: "SS", isOnline: true, hasAvatar: false },
    { name: "Shariff Shaz", initials: "SS", isOnline: true, hasAvatar: true, avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80" },
  ];

  const creatorAvatars = [
    "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=facearea&facepad=2&w=32&h=32&q=80",
    "https://images.unsplash.com/photo-1494790108755-2616b612b5bc?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=facearea&facepad=2&w=32&h=32&q=80",
    "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=facearea&facepad=2&w=32&h=32&q=80",
    "https://images.unsplash.com/photo-1517365830460-955ce3ccd263?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=facearea&facepad=2&w=32&h=32&q=80",
  ];

  return (
    <section id="community" className="py-20 bg-black">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <p className="text-lg text-brand-gray max-w-3xl mx-auto">
            Connect with creators, innovators, and product enthusiasts from around the world
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-start">
          {/* Left Column - Stats and Why Join */}
          <div className="space-y-8">
            {/* Community Stats Grid */}
            <div className="grid grid-cols-2 gap-4">
              {communityStats.map((stat, index) => (
                <div 
                  key={index}
                  className="bg-brand-gray-darker border border-brand-gray-dark rounded-xl p-6 text-center hover:border-brand-green/30 transition-all duration-300 group"
                >
                  <div className={`w-12 h-12 mx-auto mb-3 ${stat.bgColor} rounded-lg flex items-center justify-center group-hover:scale-110 transition-transform duration-300`}>
                    <stat.icon className={`w-6 h-6 ${stat.color}`} />
                  </div>
                  <div className="text-2xl font-bold text-white mb-1">{stat.value}</div>
                  <div className="text-sm text-brand-gray">{stat.label}</div>
                </div>
              ))}
            </div>

            {/* Why Join Dualite */}
            <div className="bg-brand-gray-darker border border-brand-gray-dark rounded-xl p-6">
              <h3 className="text-xl font-bold text-white mb-4">Why Join Dualite?</h3>
              <ul className="space-y-3">
                {whyJoinPoints.map((point, index) => (
                  <li key={index} className="flex items-start gap-3">
                    <div className="w-2 h-2 bg-brand-green rounded-full mt-2 flex-shrink-0"></div>
                    <span className="text-brand-gray-light text-sm">{point}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          {/* Right Column - Recently Active Creators */}
          <div className="bg-brand-gray-darker border border-brand-gray-dark rounded-xl p-6">
            <h3 className="text-xl font-bold text-white mb-6">Recently Active Creators</h3>
            
            <div className="space-y-4 mb-8">
              {recentCreators.map((creator, index) => (
                <div key={index} className="flex items-center justify-between group hover:bg-brand-gray-dark/30 rounded-lg p-2 transition-colors duration-200">
                  <div className="flex items-center gap-3">
                    <div className="relative">
                      {creator.hasAvatar && creator.avatar ? (
                        <img 
                          src={creator.avatar} 
                          alt={creator.name}
                          className="w-10 h-10 rounded-full object-cover"
                        />
                      ) : (
                        <div className="w-10 h-10 bg-brand-gray-dark rounded-full flex items-center justify-center text-white font-medium text-sm">
                          {creator.initials}
                        </div>
                      )}
                      {creator.isOnline && (
                        <div className="absolute -bottom-0.5 -right-0.5 w-3 h-3 bg-brand-green rounded-full border-2 border-brand-gray-darker"></div>
                      )}
                    </div>
                    <div>
                      <div className="text-white font-medium text-sm">{creator.name}</div>
                      <div className="text-brand-gray text-xs">Active now</div>
                    </div>
                  </div>
                  <div className="bg-brand-green/20 text-brand-green text-xs px-2 py-1 rounded-md font-medium">
                    Creator
                  </div>
                </div>
              ))}
            </div>

            {/* Join Creators CTA */}
            <div className="text-center pt-4 border-t border-brand-gray-dark/50">
              <div className="text-brand-gray text-sm mb-2">Join over 12,500 creators</div>
              <div className="flex items-center justify-center gap-1">
                {creatorAvatars.map((avatar, index) => (
                  <img 
                    key={index}
                    src={avatar}
                    alt="Creator"
                    className="w-6 h-6 rounded-full border border-brand-gray-dark"
                    style={{ marginLeft: index > 0 ? '-4px' : '0' }}
                  />
                ))}
                <div className="w-6 h-6 bg-brand-gray-dark rounded-full border border-brand-gray-dark flex items-center justify-center text-brand-gray text-xs font-bold ml-1">
                  +
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default CommunitySection;
